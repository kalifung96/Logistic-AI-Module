﻿# 整合与修改记录

## 来源
Member6：FastAPI 业务后端、SQLAlchemy/SQLite、订单/库存/物流/异常及演示认证。
ui 文件夹：用户指定的页面设计，包含移动端样式、焦点提示、提交反馈和物流时间线。
Member8：AI predictor、训练与评估脚本、合成数据、joblib 模型、集成补丁和测试。

## 本次完成
- 安装 Python 3.12 和运行依赖，启动原 Member6 后端。
- 为后端制作表单式操作界面，之后改为英文。
- 准备四页英文 PPT 文案、英文讲稿和实际界面截图。
- 制作 Member6 小组交接包。
- 检查新增 AI 页面，发现独立 HTML 无法直接访问后端且原后端缺少 ETA 接口。
- 按用户最终要求，以 ui 文件夹中的设计为基础，接入 Member8 的带 AI 后端。
- 在运单表单增加距离、重量和服务类型；增加 AI estimate 显示、加载和失败提示。
- 保留原项目文件夹；整合版本另存，使用 8002 端口避免与原 8001 服务冲突。

## 验证
- Member8 提供的测试在本机运行：30 passed（含模块及集成测试）。
- 对最终 main.py 使用独立临时数据库验证：登录、创建订单、创建带参数运单、未发货返回 unavailable、更新为 in_transit、返回 available。
- 一次样例预测为 0.96 小时；该数值受发货时间特征影响，不保证后续相同。
- 浏览器验证英文登录、页面切换及新增 AI 输入和操作入口显示。
- 尚未对三个角色的全部浏览器操作、所有屏幕尺寸和多人并发做完整回归测试。
- 测试存在依赖弃用警告，未影响本次通过。

## 交接提示
历史证据文件是组员原有记录，不应与本次本机验证混淆。历史截图可能含旧数据库内容；分享版整合项目初次运行为空。
原数据库升级时先备份，再运行 integration/migrate_sqlite.py 指定数据库路径。
自动化测试：在 01-Integrated-App 目录、依赖安装完成后运行 python -m pytest ai_module/tests -q。
verify_integration.py 验证最终 main.py，使用临时数据库，不向演示数据库添加记录。
本次分享包包含 AI 辅助生成的界面、整合和汇报内容；组员应依课程要求如实披露，保留原 AI-use-declaration.md 作为参考。

## 2026-10-31 更新（Member 8 最终提交版）
- 02-Original-Projects 中的 Member8-AI-module 已替换为 Member 8 最新版（补齐 integration/ui_with_ai.html、FRONTEND-ADDITION.md 及更新的 INTEGRATION.md）。
- Member 8 的报告段落、AI 使用声明、Q&A 准备与学习指南已更新为“已采纳整合”状态；logbook 已填写完成。
- 新增 08-Member8-Final-Deliverables：整合验证报告、最终 logbook、最终报告段落、最终 AI 使用声明。
- 以上更新不改变任何源码：01-Integrated-App 中的 main.py、ui.html、ai_module 与此前验证版本完全一致。
