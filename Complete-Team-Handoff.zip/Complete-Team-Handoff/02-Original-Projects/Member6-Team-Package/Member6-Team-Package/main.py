"""
Member 6 - Backend Core Developer
Coursework demo backend aligned with the supplied architecture diagrams.

Run:
  pip install -r requirements.txt
  uvicorn main:app --reload

Swagger UI: http://127.0.0.1:8000/docs
Default demo users:
  admin / admin123  (admin)
  courier / courier123 (courier)
  customer / customer123 (customer)

For coursework/demo only. Replace demo authentication and secrets before production.
"""
from datetime import datetime, timezone
from enum import Enum
from typing import Optional, List

from fastapi import FastAPI, Depends, HTTPException, Header, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from pydantic import BaseModel, Field, ConfigDict
from sqlalchemy import create_engine, String, Integer, Float, DateTime, ForeignKey, Text
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, sessionmaker, Session, relationship
import secrets

DATABASE_URL = "sqlite:///./delivery_demo.db"  # For PostgreSQL, set DATABASE_URL in your environment.
# Example PostgreSQL URL: postgresql+psycopg://username:password@localhost:5432/delivery_db
import os
DATABASE_URL = os.getenv("DATABASE_URL", DATABASE_URL)
connect_args = {"check_same_thread": False} if DATABASE_URL.startswith("sqlite") else {}
engine = create_engine(DATABASE_URL, connect_args=connect_args)
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)

class Base(DeclarativeBase):
    pass

class Role(str, Enum):
    admin = "admin"
    customer = "customer"
    courier = "courier"

class OrderStatus(str, Enum):
    created = "created"
    processing = "processing"
    shipped = "shipped"
    delivered = "delivered"
    cancelled = "cancelled"

class ShipmentStatus(str, Enum):
    pending = "pending"
    picked_up = "picked_up"
    in_transit = "in_transit"
    delivered = "delivered"
    exception = "exception"

class User(Base):
    __tablename__ = "users"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    username: Mapped[str] = mapped_column(String(80), unique=True, index=True)
    role: Mapped[str] = mapped_column(String(20), default="customer")

class Order(Base):
    __tablename__ = "orders"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    customer_name: Mapped[str] = mapped_column(String(120))
    item: Mapped[str] = mapped_column(String(200))
    quantity: Mapped[int] = mapped_column(Integer)
    status: Mapped[str] = mapped_column(String(30), default="created")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

class InventoryItem(Base):
    __tablename__ = "inventory"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    name: Mapped[str] = mapped_column(String(200), unique=True, index=True)
    quantity: Mapped[int] = mapped_column(Integer, default=0)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class Shipment(Base):
    __tablename__ = "shipments"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    order_id: Mapped[int] = mapped_column(ForeignKey("orders.id"), index=True)
    courier_name: Mapped[Optional[str]] = mapped_column(String(120), nullable=True)
    status: Mapped[str] = mapped_column(String(30), default="pending")
    current_location: Mapped[Optional[str]] = mapped_column(String(200), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

class TrackingLog(Base):
    __tablename__ = "tracking_logs"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    shipment_id: Mapped[int] = mapped_column(ForeignKey("shipments.id"), index=True)
    status: Mapped[str] = mapped_column(String(30))
    location: Mapped[str] = mapped_column(String(200))
    note: Mapped[str] = mapped_column(Text, default="")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

class ExceptionRecord(Base):
    __tablename__ = "exceptions"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    shipment_id: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    order_id: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    category: Mapped[str] = mapped_column(String(80))
    description: Mapped[str] = mapped_column(Text)
    status: Mapped[str] = mapped_column(String(30), default="open")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

Base.metadata.create_all(bind=engine)

def seed_users():
    db = SessionLocal()
    try:
        defaults = [("admin", "admin"), ("courier", "courier"), ("customer", "customer")]
        for username, role in defaults:
            if not db.query(User).filter(User.username == username).first():
                db.add(User(username=username, role=role))
        db.commit()
    finally:
        db.close()
seed_users()

app = FastAPI(
    title="Delivery Management Backend API",
    description="Member 6 coursework demo: authentication/RBAC, orders, shipments, tracking, inventory and exceptions.",
    version="1.0.0",
)
security = HTTPBearer(auto_error=False)

class UserOut(BaseModel):
    id: int
    username: str
    role: str
    model_config = ConfigDict(from_attributes=True)

class LoginIn(BaseModel):
    username: str = Field(..., examples=["admin"])
    password: str = Field(..., examples=["admin123"])

class TokenOut(BaseModel):
    access_token: str
    token_type: str = "bearer"
    role: str

class OrderCreate(BaseModel):
    customer_name: str = Field(..., min_length=1, max_length=120)
    item: str = Field(..., min_length=1, max_length=200)
    quantity: int = Field(..., gt=0)

class OrderUpdate(BaseModel):
    customer_name: Optional[str] = Field(None, min_length=1, max_length=120)
    item: Optional[str] = Field(None, min_length=1, max_length=200)
    quantity: Optional[int] = Field(None, gt=0)
    status: Optional[OrderStatus] = None

class OrderOut(BaseModel):
    id: int
    customer_name: str
    item: str
    quantity: int
    status: str
    created_at: datetime
    model_config = ConfigDict(from_attributes=True)

class InventoryCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=200)
    quantity: int = Field(0, ge=0)

class StockMovement(BaseModel):
    quantity: int = Field(..., gt=0)

class InventoryOut(BaseModel):
    id: int
    name: str
    quantity: int
    updated_at: datetime
    model_config = ConfigDict(from_attributes=True)

class ShipmentCreate(BaseModel):
    order_id: int
    courier_name: Optional[str] = None

class ShipmentUpdate(BaseModel):
    status: ShipmentStatus
    current_location: str = Field(..., min_length=1, max_length=200)
    note: str = ""

class ShipmentOut(BaseModel):
    id: int
    order_id: int
    courier_name: Optional[str]
    status: str
    current_location: Optional[str]
    created_at: datetime
    model_config = ConfigDict(from_attributes=True)

class ExceptionCreate(BaseModel):
    shipment_id: Optional[int] = None
    order_id: Optional[int] = None
    category: str = Field(..., min_length=1, max_length=80)
    description: str = Field(..., min_length=1)

class ExceptionResolve(BaseModel):
    status: str = Field("resolved", pattern="^(resolved|closed)$")

class ExceptionOut(BaseModel):
    id: int
    shipment_id: Optional[int]
    order_id: Optional[int]
    category: str
    description: str
    status: str
    created_at: datetime
    model_config = ConfigDict(from_attributes=True)

# Demo-only token store. Replace with signed JWTs and hashed passwords in production.
TOKENS = {
    "admin-demo-token": {"username": "admin", "role": "admin"},
    "courier-demo-token": {"username": "courier", "role": "courier"},
    "customer-demo-token": {"username": "customer", "role": "customer"},
}
DEMO_PASSWORDS = {"admin": "admin123", "courier": "courier123", "customer": "customer123"}

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

def current_user(credentials: Optional[HTTPAuthorizationCredentials] = Depends(security)):
    if credentials is None or credentials.credentials not in TOKENS:
        raise HTTPException(status_code=401, detail="Missing or invalid bearer token")
    return TOKENS[credentials.credentials]

def require_roles(*roles: str):
    def checker(user=Depends(current_user)):
        if user["role"] not in roles:
            raise HTTPException(status_code=403, detail="You do not have permission to perform this action")
        return user
    return checker

@app.get("/", tags=["System"])
def root():
    return {"message": "Delivery Management Backend API", "docs": "/docs", "health": "/health"}

@app.get("/health", tags=["System"])
def health():
    return {"status": "ok"}

@app.post("/api/v1/auth/login", response_model=TokenOut, tags=["Authentication"])
def login(payload: LoginIn, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.username == payload.username).first()
    if not user or DEMO_PASSWORDS.get(payload.username) != payload.password:
        raise HTTPException(status_code=401, detail="Incorrect username or password")
    token = {"admin": "admin-demo-token", "courier": "courier-demo-token", "customer": "customer-demo-token"}[user.role]
    return TokenOut(access_token=token, role=user.role)

@app.get("/api/v1/auth/me", tags=["Authentication"])
def me(user=Depends(current_user)):
    return {"username": user["username"], "role": user["role"]}

@app.post("/api/v1/orders", response_model=OrderOut, status_code=201, tags=["Orders"])
def create_order(payload: OrderCreate, db: Session = Depends(get_db), user=Depends(require_roles("admin", "customer"))):
    order = Order(**payload.model_dump())
    db.add(order)
    db.commit()
    db.refresh(order)
    return order

@app.get("/api/v1/orders", response_model=List[OrderOut], tags=["Orders"])
def list_orders(db: Session = Depends(get_db), user=Depends(current_user)):
    return db.query(Order).order_by(Order.id.desc()).all()

@app.get("/api/v1/orders/{order_id}", response_model=OrderOut, tags=["Orders"])
def get_order(order_id: int, db: Session = Depends(get_db), user=Depends(current_user)):
    order = db.get(Order, order_id)
    if not order:
        raise HTTPException(status_code=404, detail="Order not found")
    return order

@app.patch("/api/v1/orders/{order_id}", response_model=OrderOut, tags=["Orders"])
def update_order(order_id: int, payload: OrderUpdate, db: Session = Depends(get_db), user=Depends(require_roles("admin"))):
    order = db.get(Order, order_id)
    if not order:
        raise HTTPException(status_code=404, detail="Order not found")
    for key, value in payload.model_dump(exclude_unset=True).items():
        setattr(order, key, value.value if isinstance(value, Enum) else value)
    db.commit()
    db.refresh(order)
    return order

@app.delete("/api/v1/orders/{order_id}", status_code=204, tags=["Orders"])
def delete_order(order_id: int, db: Session = Depends(get_db), user=Depends(require_roles("admin"))):
    order = db.get(Order, order_id)
    if not order:
        raise HTTPException(status_code=404, detail="Order not found")
    if db.query(Shipment).filter(Shipment.order_id == order_id).first():
        raise HTTPException(status_code=409, detail="Cannot delete an order that has a shipment")
    db.delete(order)
    db.commit()
    return None

@app.post("/api/v1/inventory", response_model=InventoryOut, status_code=201, tags=["Inventory"])
def create_inventory_item(payload: InventoryCreate, db: Session = Depends(get_db), user=Depends(require_roles("admin"))):
    if db.query(InventoryItem).filter(InventoryItem.name == payload.name).first():
        raise HTTPException(status_code=409, detail="Inventory item already exists")
    item = InventoryItem(**payload.model_dump())
    db.add(item)
    db.commit()
    db.refresh(item)
    return item

@app.get("/api/v1/inventory", response_model=List[InventoryOut], tags=["Inventory"])
def list_inventory(db: Session = Depends(get_db), user=Depends(current_user)):
    return db.query(InventoryItem).order_by(InventoryItem.name).all()

@app.post("/api/v1/inventory/{item_id}/stock-in", response_model=InventoryOut, tags=["Inventory"])
def stock_in(item_id: int, payload: StockMovement, db: Session = Depends(get_db), user=Depends(require_roles("admin", "courier"))):
    item = db.get(InventoryItem, item_id)
    if not item:
        raise HTTPException(status_code=404, detail="Inventory item not found")
    item.quantity += payload.quantity
    db.commit()
    db.refresh(item)
    return item

@app.post("/api/v1/inventory/{item_id}/stock-out", response_model=InventoryOut, tags=["Inventory"])
def stock_out(item_id: int, payload: StockMovement, db: Session = Depends(get_db), user=Depends(require_roles("admin", "courier"))):
    item = db.get(InventoryItem, item_id)
    if not item:
        raise HTTPException(status_code=404, detail="Inventory item not found")
    if item.quantity < payload.quantity:
        raise HTTPException(status_code=409, detail="Insufficient inventory")
    item.quantity -= payload.quantity
    db.commit()
    db.refresh(item)
    return item

@app.post("/api/v1/shipments", response_model=ShipmentOut, status_code=201, tags=["Shipments"])
def create_shipment(payload: ShipmentCreate, db: Session = Depends(get_db), user=Depends(require_roles("admin"))):
    order = db.get(Order, payload.order_id)
    if not order:
        raise HTTPException(status_code=404, detail="Order not found")
    if db.query(Shipment).filter(Shipment.order_id == payload.order_id).first():
        raise HTTPException(status_code=409, detail="A shipment already exists for this order")
    shipment = Shipment(order_id=payload.order_id, courier_name=payload.courier_name, status="pending")
    order.status = "processing"
    db.add(shipment)
    db.commit()
    db.refresh(shipment)
    return shipment

@app.get("/api/v1/shipments", response_model=List[ShipmentOut], tags=["Shipments"])
def list_shipments(db: Session = Depends(get_db), user=Depends(current_user)):
    return db.query(Shipment).order_by(Shipment.id.desc()).all()

@app.get("/api/v1/shipments/{shipment_id}", response_model=ShipmentOut, tags=["Shipments"])
def get_shipment(shipment_id: int, db: Session = Depends(get_db), user=Depends(current_user)):
    shipment = db.get(Shipment, shipment_id)
    if not shipment:
        raise HTTPException(status_code=404, detail="Shipment not found")
    return shipment

@app.patch("/api/v1/shipments/{shipment_id}/tracking", response_model=ShipmentOut, tags=["Tracking"])
def update_tracking(shipment_id: int, payload: ShipmentUpdate, db: Session = Depends(get_db), user=Depends(require_roles("admin", "courier"))):
    shipment = db.get(Shipment, shipment_id)
    if not shipment:
        raise HTTPException(status_code=404, detail="Shipment not found")
    shipment.status = payload.status.value
    shipment.current_location = payload.current_location
    log = TrackingLog(shipment_id=shipment.id, status=payload.status.value, location=payload.current_location, note=payload.note)
    db.add(log)
    order = db.get(Order, shipment.order_id)
    if order and payload.status == ShipmentStatus.delivered:
        order.status = "delivered"
    if payload.status == ShipmentStatus.exception:
        db.add(ExceptionRecord(shipment_id=shipment.id, order_id=shipment.order_id, category="shipment_status", description=payload.note or "Shipment marked as exception"))
    db.commit()
    db.refresh(shipment)
    return shipment

@app.get("/api/v1/shipments/{shipment_id}/tracking", tags=["Tracking"])
def tracking_timeline(shipment_id: int, db: Session = Depends(get_db), user=Depends(current_user)):
    if not db.get(Shipment, shipment_id):
        raise HTTPException(status_code=404, detail="Shipment not found")
    return db.query(TrackingLog).filter(TrackingLog.shipment_id == shipment_id).order_by(TrackingLog.created_at).all()

@app.post("/api/v1/exceptions", response_model=ExceptionOut, status_code=201, tags=["Exceptions"])
def create_exception(payload: ExceptionCreate, db: Session = Depends(get_db), user=Depends(require_roles("admin", "courier"))):
    if payload.order_id is None and payload.shipment_id is None:
        raise HTTPException(status_code=422, detail="Provide shipment_id or order_id")
    if payload.shipment_id is not None and not db.get(Shipment, payload.shipment_id):
        raise HTTPException(status_code=404, detail="Shipment not found")
    if payload.order_id is not None and not db.get(Order, payload.order_id):
        raise HTTPException(status_code=404, detail="Order not found")
    record = ExceptionRecord(**payload.model_dump())
    db.add(record)
    db.commit()
    db.refresh(record)
    return record

@app.get("/api/v1/exceptions", response_model=List[ExceptionOut], tags=["Exceptions"])
def list_exceptions(db: Session = Depends(get_db), user=Depends(require_roles("admin", "courier"))):
    return db.query(ExceptionRecord).order_by(ExceptionRecord.id.desc()).all()

@app.patch("/api/v1/exceptions/{exception_id}", response_model=ExceptionOut, tags=["Exceptions"])
def resolve_exception(exception_id: int, payload: ExceptionResolve, db: Session = Depends(get_db), user=Depends(require_roles("admin"))):
    record = db.get(ExceptionRecord, exception_id)
    if not record:
        raise HTTPException(status_code=404, detail="Exception not found")
    record.status = payload.status
    db.commit()
    db.refresh(record)
    return record

# Local graphical interface for the coursework demonstration.
from pathlib import Path
from fastapi.responses import FileResponse

@app.get('/app', include_in_schema=False)
def graphical_workspace():
    return FileResponse(Path(__file__).with_name('ui.html'))
