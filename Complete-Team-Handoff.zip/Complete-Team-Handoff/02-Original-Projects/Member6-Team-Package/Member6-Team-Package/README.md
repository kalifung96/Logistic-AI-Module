# Member 6 — Backend Core Developer

## What this project covers
This demo implements the backend responsibilities shown in the group's diagrams:
- REST API entry point (FastAPI stands in for the API Gateway in this coursework demo)
- Authentication and role-based access control (RBAC)
- Order CRUD
- Shipment management
- Tracking timeline and status updates
- Inventory stock-in / stock-out
- Exception reporting and resolution
- SQLAlchemy repository/data-access layer
- SQLite by default for easy local demonstration; PostgreSQL is supported through `DATABASE_URL`

## 1. Install Python
Use Python 3.10 or newer. Check in a terminal:
```bash
python --version
```

## 2. Install packages
Open a terminal in this folder and run:
```bash
python -m pip install -r requirements.txt
```

## 3. Start the backend
```bash
uvicorn main:app --reload
```
The API will run at `http://127.0.0.1:8000`.

## 4. Open Swagger API documentation
Open this address in a browser:
`http://127.0.0.1:8000/docs`

You can try the endpoints directly from Swagger. The app creates `delivery_demo.db` automatically when first run.

## Demo accounts
| Username | Password | Role |
|---|---|---|
| admin | admin123 | admin |
| courier | courier123 | courier |
| customer | customer123 | customer |

For the assignment demo, the login endpoint returns a fixed demo bearer token. In Swagger, click **Authorize** and enter one of these tokens (without quotes):
- `admin-demo-token`
- `courier-demo-token`
- `customer-demo-token`

Example: use `admin-demo-token` to create an order, then create a shipment for that order. Use the courier token to update tracking.

## Main endpoints
| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/health` | Health check |
| POST | `/api/v1/auth/login` | Demo login |
| GET | `/api/v1/auth/me` | Current user and role |
| POST | `/api/v1/orders` | Create order |
| GET | `/api/v1/orders` | List orders |
| GET | `/api/v1/orders/{order_id}` | Get order |
| PATCH | `/api/v1/orders/{order_id}` | Update order (admin) |
| DELETE | `/api/v1/orders/{order_id}` | Delete order (admin; no shipment attached) |
| POST | `/api/v1/inventory` | Create inventory item (admin) |
| GET | `/api/v1/inventory` | List inventory |
| POST | `/api/v1/inventory/{item_id}/stock-in` | Add stock |
| POST | `/api/v1/inventory/{item_id}/stock-out` | Remove stock |
| POST | `/api/v1/shipments` | Create shipment (admin) |
| GET | `/api/v1/shipments` | List shipments |
| GET | `/api/v1/shipments/{shipment_id}` | Get shipment |
| PATCH | `/api/v1/shipments/{shipment_id}/tracking` | Update shipment status/location |
| GET | `/api/v1/shipments/{shipment_id}/tracking` | View tracking timeline |
| POST | `/api/v1/exceptions` | Report an exception |
| GET | `/api/v1/exceptions` | List exceptions |
| PATCH | `/api/v1/exceptions/{exception_id}` | Resolve exception (admin) |

## Example request bodies

### Create order
```json
{
  "customer_name": "Alex Chen",
  "item": "Laptop",
  "quantity": 1
}
```

### Create shipment
```json
{
  "order_id": 1,
  "courier_name": "Sam Lee"
}
```

### Update tracking
```json
{
  "status": "in_transit",
  "current_location": "Phoenix sorting centre",
  "note": "Parcel scanned and dispatched"
}
```
Allowed shipment status values: `pending`, `picked_up`, `in_transit`, `delivered`, `exception`.

### Stock movement
```json
{
  "quantity": 5
}
```

### Report exception
```json
{
  "shipment_id": 1,
  "category": "delay",
  "description": "Shipment delayed due to weather"
}
```

## PostgreSQL option
Install/run PostgreSQL, create a database, then set the environment variable before starting the server.

Windows PowerShell:
```powershell
$env:DATABASE_URL="postgresql+psycopg://username:password@localhost:5432/delivery_db"
uvicorn main:app --reload
```

macOS/Linux:
```bash
export DATABASE_URL="postgresql+psycopg://username:password@localhost:5432/delivery_db"
uvicorn main:app --reload
```

## Important limitation
This is a coursework demonstration, not production-ready security. Demo tokens and passwords are hard-coded for easy presentation. A real deployment must use hashed passwords, signed short-lived JWTs, environment-managed secrets, HTTPS, stronger validation, migrations, audit logging, and tests.
