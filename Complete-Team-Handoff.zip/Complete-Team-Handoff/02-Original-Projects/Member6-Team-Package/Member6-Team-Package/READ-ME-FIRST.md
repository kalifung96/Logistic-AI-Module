﻿# Member 6 — Team Handoff / 小组交接说明

这是配送管理系统的英文界面与后端完整源码，附带四页 PPT 文字、英文讲稿和实际界面截图。

## Windows 启动方法
1. 完整解压压缩包，不要在压缩包预览窗口直接运行。
2. 安装 Python 3.10 或以上版本：https://www.python.org/downloads/ ，安装时勾选 Add Python to PATH。
3. 双击 START-WINDOWS.bat。首次运行需要联网创建独立环境并安装依赖；默认源失败会尝试清华镜像。
4. 看到 Uvicorn running 后，在浏览器打开 http://127.0.0.1:8001/app 。
5. 保持命令窗口打开；按 Ctrl+C 停止服务。

管理员：admin / admin123
配送员：courier / courier123
客户：customer / customer123

演示顺序：Orders 创建订单 → Deliveries & Tracking 安排配送 → 更新状态与位置 → View timeline 查看轨迹。另有 Inventory 和 Exceptions。

本包不包含原电脑上的虚拟环境和数据库。首次启动会自动创建新的 SQLite 数据库，因此初始订单、运单和库存为空。Presentation 文件夹中的截图展示原电脑的演示记录，不是新数据库的初始内容。

127.0.0.1 指各自电脑。原作者的本地网址不能直接作为远程网站分享；每位组员需要在自己的电脑启动本项目。
如果提示端口被占用，先检查是否已有项目在运行，避免重复启动。

## 汇报素材
Presentation/Presentation-content.md：四页英文 PPT 文字、约三分钟英文讲稿和时间安排。
Presentation/*.jpg：四张实际英文页面截图，可插入 PPT。

## 文件说明
main.py：FastAPI 后端与 /app 页面入口。
ui.html：英文操作界面。
requirements.txt：Python 依赖。
postman_collection.json：可导入 Postman 的 API 测试集合。
README.md：原始项目技术说明；使用图形界面时以本交接说明为准。

## macOS / Linux
在项目目录打开终端，依次运行：
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m uvicorn main:app --host 127.0.0.1 --port 8001
然后打开 http://127.0.0.1:8001/app 。

## 当前范围
课程演示版本，采用固定演示密码及令牌。客户数据隔离、生产认证及全面自动化测试尚待完善。库存出入库是独立操作，创建订单不会自动扣库存。
