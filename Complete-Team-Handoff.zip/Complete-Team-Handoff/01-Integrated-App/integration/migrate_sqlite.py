"""Non-destructive SQLite migration for the Member 8 AI integration patch.

Adds the three optional, nullable dispatch-detail columns to the existing
`shipments` table in an existing delivery_demo.db. SQLAlchemy's
create_all() does NOT alter existing tables, so this script is needed for
databases created before the patch. Existing rows are preserved; old
shipments simply have no AI estimate (the /eta endpoint returns
"unavailable" for them).

Back up the database first:
    copy delivery_demo.db delivery_demo.backup.db        (Windows)
    cp delivery_demo.db delivery_demo.backup.db          (macOS/Linux)

Run (idempotent — safe to run more than once):
    python integration/migrate_sqlite.py [path-to-db]

The script only adds columns; it never deletes or modifies data.
"""

import shutil
import sqlite3
import sys
from pathlib import Path

NEW_COLUMNS = [
    ("distance_km", "REAL"),
    ("weight_kg", "REAL"),
    ("service_type", "TEXT"),
]


def migrate(db_path: Path, make_backup: bool = True) -> int:
    if not db_path.exists():
        print(f"Database not found: {db_path}")
        print("Nothing to migrate. Start the backend once first, or use a fresh DATABASE_URL.")
        return 0

    if make_backup:
        backup = db_path.with_name(db_path.stem + ".backup.db")
        if not backup.exists():
            shutil.copy2(db_path, backup)
            print(f"Backup written: {backup}")

    conn = sqlite3.connect(db_path)
    try:
        table_info = conn.execute("PRAGMA table_info(shipments)").fetchall()
        if not table_info:
            print("No 'shipments' table found; nothing to migrate.")
            return 0
        existing = {row[1] for row in table_info}
        added = 0
        for name, coltype in NEW_COLUMNS:
            if name in existing:
                print(f"Column shipments.{name} already exists; skipped.")
                continue
            conn.execute(f"ALTER TABLE shipments ADD COLUMN {name} {coltype}")
            added += 1
            print(f"Added column shipments.{name} ({coltype})")
        conn.commit()
        print(f"Done. {added} column(s) added. Existing rows are preserved.")
        return added
    finally:
        conn.close()


if __name__ == "__main__":
    default_db = Path(__file__).resolve().parent.parent / "delivery_demo.db"
    target = Path(sys.argv[1]) if len(sys.argv) > 1 else default_db
    migrate(target)
