# Member 8 → Member 7 / Member 6 frontend addition

This is Member 7's improved `ui.html` (mobile CSS, focus styles, saving
feedback, tracking timeline) with clearly marked **MEMBER 8 ADDITION** blocks
(search for "MEMBER 8 ADDITION"). It is a proposal, prepared for team review —
not an approved change until Member 7 (who owns the frontend) and the team
accept it.

## What the addition does

Three small, non-breaking changes:

1. **Optional dispatch details on the admin "Assign delivery" form**:
   distance (km), weight (kg), service type. Left empty = not sent — the form
   works exactly as before if they are ignored.
2. **"AI delivery estimate" form** next to the tracking timeline: select a
   shipment, view the estimate from `GET /api/v1/shipments/{id}/eta`.
3. Empty optional fields are omitted on submit, so empty strings never reach
   the API.

## Compatibility (verified 30 Oct 2026)

- Works with the **patched backend** (`main_with_ai.py`): full flow tested —
  shipment with details (numbers sent as form strings are accepted), dispatch,
  estimate `available` (0.96 h), pending shipment → "not dispatched yet".
- Works with the **original backend** (`main.py`): the extra form fields are
  silently ignored by the original `POST /api/v1/shipments`, so the UI keeps
  working even before the backend patch is adopted. (Verified: shipment
  creation without optional fields is accepted by both.)
- Shipment creation without any optional fields is accepted in both cases.

## How to deploy

Back up the current `ui.html`, then replace it with this file (or apply the
marked blocks to Member 7's latest version — the additions are intentionally
small so they re-apply easily). No API or backend change is required for the
UI itself; the estimate form only shows data once the `/eta` endpoint exists
(patched backend).

## Honest scope

This is a **review draft**: verified by endpoint tests and JS syntax check, but
not click-tested in a browser by Member 8. Browser walkthroughs (admin,
courier, customer), viewport matrix and error handling remain Member 7's QA
scope, consistent with her own handoff notes.

## Provenance

Base UI: Member 7's package (handed to Member 6). Additions: AI-assisted work
prepared for Member 8. Personal contribution and AI disclosure should describe
the actual work honestly.
