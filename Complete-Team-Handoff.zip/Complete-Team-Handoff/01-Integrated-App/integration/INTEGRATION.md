# Integration with Member 6's Backend — Member 8 Proposal

This folder contains a **tested integration proposal** for connecting the AI
module to Member 6's FastAPI backend. It is not an approved or completed part of
the group system until Member 6 (and the team) review and approve it.

## What was integrated

Member 6's backend (FastAPI + SQLAlchemy + SQLite, demo bearer tokens, RBAC)
has endpoints for orders, shipments, tracking, inventory and exceptions — but
its data model had none of the AI module's five inputs. The patch adds:

1. Three optional, nullable dispatch-detail columns on `Shipment`:
   `distance_km`, `weight_kg`, `service_type`.
2. Those fields (validated: 1-60 km, 0.1-25 kg, standard/express) on
   `ShipmentCreate` and `ShipmentOut`.
3. One new authenticated endpoint, using Member 6's existing auth pattern:

```
GET /api/v1/shipments/{shipment_id}/eta
```

## Dispatch and timezone policies (proposed for team approval)

- **Dispatch = the first `in_transit` tracking event**, not shipment creation
  (shipments are created as `pending`). Before that event the ETA endpoint
  returns `unavailable` with "Shipment not dispatched yet".
- **Delivered shipments** return `eta_status: "not_applicable"`.
- The estimate is the **total duration from dispatch**, not time remaining.
- Timestamps are stored as UTC. The model's hour/weekday features are computed
  in Asia/Hong_Kong time (UTC+8, no DST), and the response says so.

## Response examples (from a live run, 29 Oct 2026)

Pending shipment:
```json
{"shipment_id": 1, "eta_status": "unavailable", "predicted_duration_hours": null,
 "model_version": null, "message": "Shipment not dispatched yet (no in_transit tracking event)",
 "basis": "Estimated total duration from dispatch (not time remaining now)"}
```

Dispatched shipment:
```json
{"shipment_id": 1, "eta_status": "available", "predicted_duration_hours": 0.94,
 "model_version": "eta-v1", "message": null,
 "basis": "Estimated total duration from dispatch (not time remaining now)",
 "dispatched_at_utc": "2026-10-29T11:16:25Z", "dispatch_hour_local": 19,
 "dispatch_weekday_local": 3, "timezone": "UTC+8 (Asia/Hong_Kong, no DST)"}
```

Delivered shipment:
```json
{"shipment_id": 1, "eta_status": "not_applicable", "predicted_duration_hours": null,
 "message": "Shipment already delivered", ...}
```

## Files

| File | Purpose |
|------|---------|
| `integration/main_with_ai.py` | Member 6's `main.py` with clearly marked Member 8 additions (search "MEMBER 8 ADDITION") |
| `integration/migrate_sqlite.py` | Non-destructive migration: adds the three nullable columns to an existing `delivery_demo.db` (backs up first, idempotent) |
| `../ai_module/export_training_records.py` | Exports delivered shipments (dispatch → delivered) as training CSV |
| `../ai_module/tests/test_integration.py` | 8 integration tests for the /eta endpoint |

## How Member 6 deploys the patch

Target layout — the patched backend, the AI module, and the model artifact
(`artifacts/` is a separate folder, NOT inside `ai_module/`) in one folder:

```text
backend/
├── main.py                        # Member 6 original, unchanged
├── main_with_ai.py                # proposed patched copy (integration/)
├── ui.html                        # existing interface
├── requirements.txt               # this package's pinned deps (supersedes
│                                  # Member 6's original list for the demo)
├── integration/
│   └── migrate_sqlite.py          # run for an existing delivery_demo.db
├── ai_module/                     # copied from this package
└── artifacts/
    └── delivery_duration_model.joblib   # copied from this package
```

Steps:

1. **Review the diff**: compare `integration/main_with_ai.py` with the original
   `main.py`. All Member 8 additions are marked `MEMBER 8 ADDITION`.
2. **Install dependencies**:
   `python -m pip install -r requirements.txt` (includes SQLAlchemy for the
   patched backend).
3. **Existing database? Back it up first** (if it exists):
   `cp delivery_demo.db delivery_demo.backup.db`, then run
   `python integration/migrate_sqlite.py` — non-destructive, idempotent,
   preserves all existing rows. **Fresh demo?** Point `DATABASE_URL` at a new
   SQLite file. Do NOT delete `delivery_demo.db`.
4. Start the patched backend:

```bash
python -m uvicorn main_with_ai:app --host 127.0.0.1 --port 8001
```

5. Open http://127.0.0.1:8001/app for the original interface, or
   http://127.0.0.1:8001/docs for Swagger, and run the demo script below.

This exact layout was verified on 29 Oct 2026: old records from a database
created by the original backend remained readable after migrating (twice —
the second run added nothing and the backup was written), an old delivered
shipment without AI details returned `not_applicable`, and a new dispatched
shipment returned an available estimate (0.82 h).

## Demo script (verified live)

```bash
curl -s http://127.0.0.1:8001/health
# login (or use the fixed demo tokens directly)
curl -s -X POST http://127.0.0.1:8001/api/v1/auth/login \
  -H 'Content-Type: application/json' -d '{"username":"admin","password":"admin123"}'
# create an order (admin)
curl -s -X POST http://127.0.0.1:8001/api/v1/orders \
  -H 'Content-Type: application/json' -H 'Authorization: Bearer admin-demo-token' \
  -d '{"customer_name":"Alex Chen","item":"Laptop","quantity":1}'
# create a shipment WITH dispatch details (admin)
curl -s -X POST http://127.0.0.1:8001/api/v1/shipments \
  -H 'Content-Type: application/json' -H 'Authorization: Bearer admin-demo-token' \
  -d '{"order_id":1,"courier_name":"Sam Lee","distance_km":18.5,"weight_kg":2.0,"service_type":"standard"}'
# ETA before dispatch -> unavailable "not dispatched"
curl -s http://127.0.0.1:8001/api/v1/shipments/1/eta -H 'Authorization: Bearer customer-demo-token'
# dispatch (courier)
curl -s -X PATCH http://127.0.0.1:8001/api/v1/shipments/1/tracking \
  -H 'Content-Type: application/json' -H 'Authorization: Bearer courier-demo-token' \
  -d '{"status":"in_transit","current_location":"Phoenix sorting centre","note":"Dispatched"}'
# ETA after dispatch -> available
curl -s http://127.0.0.1:8001/api/v1/shipments/1/eta -H 'Authorization: Bearer customer-demo-token'
```

## Postman additions

Add to the team collection (same headers as existing requests,
`Authorization: Bearer admin-demo-token`):

- `GET {{base_url}}/api/v1/shipments/{shipment_id}/eta` — view estimate
- `POST {{base_url}}/api/v1/shipments` — body now may include
  `distance_km`, `weight_kg`, `service_type`

## Retraining on exported records (export is export-only)

`ai_module/export_training_records.py` only exports a CSV; it does not
retrain. Once the database holds REAL deliveries (not demo clicks), the
procedure is:

1. `python -m ai_module.export_training_records path/to/delivery_demo.db`
   → writes `data/exported_records.csv` (the synthetic dataset is never
   overwritten).
2. Back up the current model and dataset, then REPLACE the entire
   `data/deliveries.csv` with the exported CSV (do not edit DATA_PATH —
   `evaluate_model.py` reads the same file and must see the same data).
3. `python -m ai_module.train_model` (retrains and saves a new artifact)
4. `python -m ai_module.evaluate_model` (new MAE vs baseline)
5. `python -m pytest ai_module/tests -v` (all tests must still pass)

State in the report whether the retrained model used demonstration activity
or real operations — durations from demo tracking clicks (often seconds
apart) do not establish real-world accuracy.

## Frontend addition (proposed, on top of Member 7's UI)

`integration/ui_with_ai.html` is Member 7's improved `ui.html` plus marked
MEMBER 8 ADDITION blocks: optional dispatch details on the admin "Assign
delivery" form, an "AI delivery estimate" view form, and empty-field cleanup on
submit. It is non-breaking with BOTH the original backend (extra fields are
silently ignored) and the patched backend (full flow verified 30 Oct 2026).
See `integration/FRONTEND-ADDITION.md` for the handoff note to Members 6 and 7.

## Honest scope boundaries

- The backend patch is **backend integration only**; the browser form did not
  collect distance/weight/service type and the estimate was not displayed.
  A proposed frontend addition now exists (`integration/ui_with_ai.html`) —
  a review draft pending Member 7's approval and browser QA.
- Results are still from **synthetic data**; real-world accuracy is not
  established.
- The 8 integration tests plus the 22 module tests all pass
  (`python -m pytest ai_module/tests -v`, 30 total).
- Tested on Python 3.14 with the versions in `requirements.txt`. The team
  should verify the same versions install on their own machines before the
  presentation (Member 6's README says Python 3.10+; the AI dependencies
  were not tested below 3.14).
- `datetime.utcnow` deprecation warnings come from Member 6's original code
  and are unchanged by this patch.
