﻿整合版使用说明
1. 安装 Python 3.12，勾选 Add Python to PATH。
2. 解压后双击 START-WINDOWS.bat，首次安装依赖需要联网。
3. 打开 http://127.0.0.1:8002/app，账号 admin，密码 admin123。
4. Orders 创建订单 → Deliveries & Tracking 创建运单，并填写距离(1–60km)、重量(0.1–25kg)和服务类型。
5. 更新物流为 In transit，再在 AI delivery estimate 选择运单并点击 View estimate。
预估是从首次发货起的总时长，不是剩余时间；模型使用合成数据训练，仅用于课程演示。
Member6 提供业务后端，Member7/ui 提供界面设计，Member8 提供预测模块及模型。原三个文件夹均保留。
此整合包从空数据库开始；截图及原汇报素材保存在 Presentation，Member8 原始资料保存在 study、evidence 和 integration。
以后已有数据库升级时，可运行 python integration/migrate_sqlite.py delivery_demo.db，先备份再加字段。
