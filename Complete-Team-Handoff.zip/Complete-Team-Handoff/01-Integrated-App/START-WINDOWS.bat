@echo off
setlocal
cd /d "%~dp0"
if exist ".venv\Scripts\python.exe" goto run
py -3 --version >nul 2>&1
if not errorlevel 1 (
  py -3 -m venv .venv
) else (
  python --version >nul 2>&1
  if errorlevel 1 goto missing
  python -m venv .venv
)
if not exist ".venv\Scripts\python.exe" goto missing
:run
.venv\Scripts\python.exe -m pip install -r requirements.txt
if not errorlevel 1 goto launch
.venv\Scripts\python.exe -m pip install -r requirements.txt -i https://pypi.tuna.tsinghua.edu.cn/simple
if errorlevel 1 goto failed
:launch
set DATABASE_URL=sqlite:///./delivery_demo.db
echo Open http://127.0.0.1:8002/app in your browser after startup.
echo Keep this window open. Press Ctrl+C to stop.
.venv\Scripts\python.exe -m uvicorn main:app --host 127.0.0.1 --port 8002
pause
exit /b
:missing
echo Please install Python 3.10 or newer from https://www.python.org/downloads/
echo Select Add Python to PATH during installation, then run this file again.
pause
exit /b 1
:failed
echo Dependency installation failed. Check your internet connection and retry.
pause
exit /b 1

