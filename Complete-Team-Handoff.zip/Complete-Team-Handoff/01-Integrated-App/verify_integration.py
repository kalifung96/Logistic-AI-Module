import os,tempfile
os.environ['DATABASE_URL']='sqlite:///'+tempfile.mktemp(suffix='.db')
from fastapi.testclient import TestClient
from main import app
c=TestClient(app); h={'Authorization':'Bearer admin-demo-token'}
assert c.get('/app').status_code==200
assert c.post('/api/v1/auth/login',json={'username':'admin','password':'admin123'}).status_code==200
o=c.post('/api/v1/orders',headers=h,json={'customer_name':'Integration Test','item':'Laptop','quantity':1}).json()
s=c.post('/api/v1/shipments',headers=h,json={'order_id':o['id'],'courier_name':'Sam','distance_km':18.5,'weight_kg':2,'service_type':'standard'}).json()
assert c.get(f"/api/v1/shipments/{s['id']}/eta",headers=h).json()['eta_status']=='unavailable'
assert c.patch(f"/api/v1/shipments/{s['id']}/tracking",headers=h,json={'status':'in_transit','current_location':'Sorting centre','note':'Dispatched'}).status_code==200
r=c.get(f"/api/v1/shipments/{s['id']}/eta",headers=h).json()
assert r['eta_status']=='available',r
print(r)
