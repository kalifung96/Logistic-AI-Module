"""Tests for the FastAPI wrapper.

Run with:  pytest ai_module/tests -v
"""

import pytest
from fastapi.testclient import TestClient

from ai_module.api import app

client = TestClient(app)

VALID_PAYLOAD = {
    "distance_km": 18.5,
    "weight_kg": 2.0,
    "service_type": "standard",
    "dispatch_hour": 10,
    "dispatch_weekday": 2,
}


class TestHealthEndpoint:
    def test_health_returns_ok(self):
        response = client.get("/health")
        assert response.status_code == 200
        assert response.json() == {"status": "ok"}


class TestPredictionEndpoint:
    def test_valid_payload_returns_estimate(self):
        response = client.post("/api/ai/predict-delivery", json=VALID_PAYLOAD)
        assert response.status_code == 200
        body = response.json()
        assert body["prediction_status"] == "available"
        assert body["predicted_duration_hours"] > 0
        assert "model_version" in body

    def test_missing_model_returns_unavailable_not_error(self, tmp_path, monkeypatch):
        """A missing model artifact must produce a clean 200 unavailable
        response, so callers can show a fallback message instead of an error."""
        from ai_module.predictor import Predictor

        broken = Predictor(model_path=tmp_path / "does_not_exist.joblib")
        monkeypatch.setattr("ai_module.api.get_predictor", lambda: broken)
        response = client.post("/api/ai/predict-delivery", json=VALID_PAYLOAD)
        assert response.status_code == 200
        body = response.json()
        assert body["prediction_status"] == "unavailable"
        assert body["predicted_duration_hours"] is None

    def test_negative_distance_returns_422(self):
        payload = {**VALID_PAYLOAD, "distance_km": -5}
        response = client.post("/api/ai/predict-delivery", json=payload)
        assert response.status_code == 422

    def test_distance_above_training_domain_returns_422(self):
        payload = {**VALID_PAYLOAD, "distance_km": 120}
        response = client.post("/api/ai/predict-delivery", json=payload)
        assert response.status_code == 422

    def test_missing_field_returns_422(self):
        payload = {k: v for k, v in VALID_PAYLOAD.items() if k != "weight_kg"}
        response = client.post("/api/ai/predict-delivery", json=payload)
        assert response.status_code == 422

    def test_unsupported_service_type_returns_422(self):
        payload = {**VALID_PAYLOAD, "service_type": "teleport"}
        response = client.post("/api/ai/predict-delivery", json=payload)
        assert response.status_code == 422
