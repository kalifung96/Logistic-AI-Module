"""Tests for the predictor wrapper.

Run with:  pytest ai_module/tests -v
"""

import pytest

from ai_module.predictor import MODEL_VERSION, PredictionUnavailableError, Predictor

VALID_SAMPLE = {
    "distance_km": 18.5,
    "weight_kg": 2.0,
    "service_type": "standard",
    "dispatch_hour": 10,
    "dispatch_weekday": 2,
}


@pytest.fixture(scope="module")
def predictor():
    return Predictor()


class TestValidPredictions:
    def test_valid_standard_shipment(self, predictor):
        result = predictor.predict(VALID_SAMPLE)
        assert result["prediction_status"] == "available"
        assert result["predicted_duration_hours"] > 0
        assert result["model_version"] == MODEL_VERSION

    def test_valid_express_shipment(self, predictor):
        sample = {**VALID_SAMPLE, "service_type": "express"}
        result = predictor.predict(sample)
        assert result["prediction_status"] == "available"

    def test_express_faster_than_standard_on_same_route(self, predictor):
        standard = predictor.predict(VALID_SAMPLE)["predicted_duration_hours"]
        express = predictor.predict({**VALID_SAMPLE, "service_type": "express"})["predicted_duration_hours"]
        assert express < standard

    def test_deterministic_repeated_prediction(self, predictor):
        a = predictor.predict(VALID_SAMPLE)
        b = predictor.predict(VALID_SAMPLE)
        assert a == b

    def test_boundary_values_at_training_domain_edges_accepted(self, predictor):
        # Training domain: distance 1-60 km, weight 0.1-25 kg.
        result = predictor.predict({**VALID_SAMPLE, "distance_km": 60.0, "weight_kg": 25.0})
        assert result["prediction_status"] == "available"

    def test_minimum_domain_values_accepted(self, predictor):
        result = predictor.predict({**VALID_SAMPLE, "distance_km": 1.0, "weight_kg": 0.1})
        assert result["prediction_status"] == "available"


class TestInvalidInput:
    def test_negative_distance_rejected(self, predictor):
        with pytest.raises(ValueError):
            predictor.predict({**VALID_SAMPLE, "distance_km": -5})

    def test_distance_above_training_domain_rejected(self, predictor):
        with pytest.raises(ValueError, match="distance_km"):
            predictor.predict({**VALID_SAMPLE, "distance_km": 120})

    def test_weight_above_training_domain_rejected(self, predictor):
        with pytest.raises(ValueError, match="weight_kg"):
            predictor.predict({**VALID_SAMPLE, "weight_kg": 30})

    def test_below_domain_values_rejected(self, predictor):
        with pytest.raises(ValueError, match="distance_km"):
            predictor.predict({**VALID_SAMPLE, "distance_km": 0.5})
        with pytest.raises(ValueError, match="weight_kg"):
            predictor.predict({**VALID_SAMPLE, "weight_kg": 0.05})

    def test_fractional_hour_rejected(self, predictor):
        with pytest.raises(ValueError, match="dispatch_hour"):
            predictor.predict({**VALID_SAMPLE, "dispatch_hour": 10.5})

    def test_missing_field_rejected(self, predictor):
        sample = dict(VALID_SAMPLE)
        del sample["weight_kg"]
        with pytest.raises(ValueError, match="weight_kg"):
            predictor.predict(sample)

    def test_unsupported_service_type_rejected(self, predictor):
        with pytest.raises(ValueError, match="service_type"):
            predictor.predict({**VALID_SAMPLE, "service_type": "teleport"})

    def test_out_of_range_hour_rejected(self, predictor):
        with pytest.raises(ValueError, match="dispatch_hour"):
            predictor.predict({**VALID_SAMPLE, "dispatch_hour": 25})


class TestFailureBehaviour:
    def test_missing_model_returns_unavailable_not_crash(self, tmp_path):
        broken = Predictor(model_path=tmp_path / "does_not_exist.joblib")
        with pytest.raises(PredictionUnavailableError, match="Estimate|Model artifact"):
            broken.predict(VALID_SAMPLE)
