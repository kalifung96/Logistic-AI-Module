"""Integration tests for the Member 8 AI patch on Member 6's backend.

These tests import the patched backend (integration/main_with_ai.py) with a
temporary DATABASE_URL, then exercise the new /eta endpoint through the
existing authentication and workflow endpoints.

Run with:  python -m pytest ai_module/tests -v
"""

import importlib.util
import os
from datetime import datetime
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

INTEGRATION_DIR = Path(__file__).resolve().parents[2] / "integration"
MAIN_WITH_AI = INTEGRATION_DIR / "main_with_ai.py"

ADMIN = {"Authorization": "Bearer admin-demo-token"}
COURIER = {"Authorization": "Bearer courier-demo-token"}


@pytest.fixture(scope="module")
def backend(tmp_path_factory):
    """Import the patched backend once against a throwaway SQLite database."""
    db_path = tmp_path_factory.mktemp("db") / "test.db"
    os.environ["DATABASE_URL"] = f"sqlite:///{db_path}"
    spec = importlib.util.spec_from_file_location("main_with_ai", MAIN_WITH_AI)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


@pytest.fixture(scope="module")
def client(backend):
    return TestClient(backend.app)


def _create_order(client) -> int:
    response = client.post(
        "/api/v1/orders",
        json={"customer_name": "Alex Chen", "item": "Laptop", "quantity": 1},
        headers=ADMIN,
    )
    assert response.status_code == 201
    return response.json()["id"]


def _create_shipment(client, order_id, **extra) -> int:
    payload = {"order_id": order_id, "courier_name": "Sam Lee", **extra}
    response = client.post("/api/v1/shipments", json=payload, headers=ADMIN)
    assert response.status_code == 201
    return response.json()["id"]


def _dispatch(client, shipment_id):
    response = client.patch(
        f"/api/v1/shipments/{shipment_id}/tracking",
        json={"status": "in_transit", "current_location": "Phoenix sorting centre", "note": "Dispatched"},
        headers=COURIER,
    )
    assert response.status_code == 200


class TestEtaEndpoint:
    def test_eta_requires_authentication(self, client):
        response = client.get("/api/v1/shipments/1/eta")
        assert response.status_code == 401

    def test_eta_unknown_shipment_returns_404(self, client):
        response = client.get("/api/v1/shipments/99999/eta", headers=ADMIN)
        assert response.status_code == 404

    def test_pending_shipment_not_dispatched(self, client):
        order_id = _create_order(client)
        shipment_id = _create_shipment(client, order_id)
        response = client.get(f"/api/v1/shipments/{shipment_id}/eta", headers=ADMIN)
        assert response.status_code == 200
        body = response.json()
        assert body["eta_status"] == "unavailable"
        assert "not dispatched" in body["message"]

    def test_dispatched_shipment_with_details_returns_estimate(self, client):
        order_id = _create_order(client)
        shipment_id = _create_shipment(
            client, order_id, distance_km=18.5, weight_kg=2.0, service_type="standard"
        )
        _dispatch(client, shipment_id)
        response = client.get(f"/api/v1/shipments/{shipment_id}/eta", headers=ADMIN)
        assert response.status_code == 200
        body = response.json()
        assert body["eta_status"] == "available"
        assert body["predicted_duration_hours"] > 0
        assert body["model_version"] == "eta-v1"
        assert body["timezone"].startswith("UTC+8")

    def test_dispatched_shipment_missing_details_unavailable(self, client):
        order_id = _create_order(client)
        shipment_id = _create_shipment(client, order_id)
        _dispatch(client, shipment_id)
        response = client.get(f"/api/v1/shipments/{shipment_id}/eta", headers=ADMIN)
        assert response.status_code == 200
        body = response.json()
        assert body["eta_status"] == "unavailable"
        assert "missing dispatch details" in body["message"]

    def test_delivered_shipment_not_applicable(self, client):
        order_id = _create_order(client)
        shipment_id = _create_shipment(
            client, order_id, distance_km=18.5, weight_kg=2.0, service_type="express"
        )
        _dispatch(client, shipment_id)
        response = client.patch(
            f"/api/v1/shipments/{shipment_id}/tracking",
            json={"status": "delivered", "current_location": "Customer address", "note": "Signed"},
            headers=COURIER,
        )
        assert response.status_code == 200
        response = client.get(f"/api/v1/shipments/{shipment_id}/eta", headers=ADMIN)
        assert response.status_code == 200
        body = response.json()
        assert body["eta_status"] == "not_applicable"
        assert "already delivered" in body["message"]

    def test_missing_model_returns_clean_unavailable(self, client, backend, tmp_path, monkeypatch):
        from ai_module.predictor import Predictor

        broken = Predictor(model_path=tmp_path / "does_not_exist.joblib")
        monkeypatch.setattr("ai_module.predictor.get_predictor", lambda: broken)

        order_id = _create_order(client)
        shipment_id = _create_shipment(
            client, order_id, distance_km=10.0, weight_kg=1.0, service_type="standard"
        )
        _dispatch(client, shipment_id)
        response = client.get(f"/api/v1/shipments/{shipment_id}/eta", headers=ADMIN)
        assert response.status_code == 200
        body = response.json()
        assert body["eta_status"] == "unavailable"
        assert "Estimate currently unavailable" in body["message"]

    def test_dispatch_hour_computed_in_hong_kong_time_with_rollover(self, client, backend):
        """A dispatch at 16:30 UTC must become 00:30 local (UTC+8) next day."""
        from datetime import timedelta

        order_id = _create_order(client)
        shipment_id = _create_shipment(
            client, order_id, distance_km=12.0, weight_kg=3.0, service_type="standard"
        )

        dispatch_utc = datetime(2026, 10, 29, 16, 30)  # Thursday 16:30 UTC
        expected_local = dispatch_utc + timedelta(hours=8)

        db = backend.SessionLocal()
        try:
            db.add(
                backend.TrackingLog(
                    shipment_id=shipment_id,
                    status="in_transit",
                    location="Test depot",
                    note="Synthetic dispatch event",
                    created_at=dispatch_utc,
                )
            )
            db.commit()
        finally:
            db.close()

        response = client.get(f"/api/v1/shipments/{shipment_id}/eta", headers=ADMIN)
        assert response.status_code == 200
        body = response.json()
        assert body["eta_status"] == "available"
        assert body["dispatch_hour_local"] == expected_local.hour
        assert body["dispatch_weekday_local"] == expected_local.weekday()
        # 16:30 UTC is already the next day in Hong Kong.
        assert expected_local.hour == 0
