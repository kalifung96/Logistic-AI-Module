"""Generate a reproducible synthetic dataset of completed deliveries.

Every record contains only information that is available at dispatch time,
plus the actual delivery duration (the label to predict).

REAL DATA SHOULD REPLACE THIS: when the team's database (Members 5/6) contains
completed shipments with dispatch-time fields, export them in this same CSV
format and retrain. Results from synthetic data demonstrate the pipeline only;
they do not establish real-world logistics accuracy.
"""

import csv
import random
from pathlib import Path

import numpy as np

SEED = 42
N_RECORDS = 4000
OUTPUT = Path(__file__).resolve().parent.parent / "data" / "deliveries.csv"

SERVICE_TYPES = ["standard", "express"]


def actual_duration_hours(rng, distance_km, weight_kg, service_type, dispatch_hour, dispatch_weekday):
    """A plausible physical relationship between dispatch-time facts and duration."""
    base_speed = 32.0 if service_type == "express" else 20.0  # km/h average progress
    duration = distance_km / base_speed
    duration += 0.05 * weight_kg  # handling time grows with weight
    if service_type == "standard" and 7 <= dispatch_hour <= 10:
        duration *= 1.20  # morning congestion penalty
    if dispatch_weekday >= 5:  # Saturday / Sunday
        duration *= 1.15
    duration *= rng.uniform(0.85, 1.15)  # unmodeled noise
    return round(max(duration, 0.25), 2)


def main():
    rng = random.Random(SEED)
    np.random.seed(SEED)
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)

    header = [
        "delivery_id",
        "distance_km",
        "weight_kg",
        "service_type",
        "dispatch_hour",
        "dispatch_weekday",
        "actual_duration_hours",
    ]
    rows = []
    for i in range(N_RECORDS):
        distance = round(rng.uniform(1.0, 60.0), 1)
        weight = round(rng.uniform(0.1, 25.0), 1)
        service = rng.choice(SERVICE_TYPES)
        hour = rng.randrange(24)
        weekday = rng.randrange(7)
        duration = actual_duration_hours(rng, distance, weight, service, hour, weekday)
        rows.append([i, distance, weight, service, hour, weekday, duration])

    with OUTPUT.open("w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(header)
        writer.writerows(rows)

    print(f"Wrote {len(rows)} records to {OUTPUT}")


if __name__ == "__main__":
    main()
