"""Export training records from the team's SQLite database (Member 8).

Reads delivery_demo.db directly (read-only) and exports delivered shipments
that have both a dispatch event (first `in_transit` tracking log) and a
delivery event (first `delivered` log after dispatch), plus the optional
dispatch-detail fields added by the integration patch.

Output: data/exported_records.csv — the same column format as
data/deliveries.csv. This script is EXPORT-ONLY: it does not retrain the
model. To retrain on an export (only meaningful once the database holds
real deliveries, not demo clicks), see the procedure in
integration/INTEGRATION.md ("Retraining on exported records").

HONESTY NOTES — read before using the export:
- The team database contains manually entered demonstration records, not
  evidence of real logistics operations. Durations computed from demo
  tracking clicks (often seconds apart) do not establish real-world accuracy.
- The export reports how many records were skipped and why.
- This file never overwrites data/deliveries.csv.

Usage:
    python -m ai_module.export_training_records [path-to-db]
"""

import csv
import sqlite3
import sys
from pathlib import Path

# Deployed layout: <backend folder>/ai_module/export_training_records.py
# with delivery_demo.db next to main.py / main_with_ai.py in <backend folder>.
DATA_DIR = Path(__file__).resolve().parent.parent / "data"
OUTPUT_PATH = DATA_DIR / "exported_records.csv"
DEFAULT_DB = Path(__file__).resolve().parent.parent / "delivery_demo.db"

HEADER = [
    "delivery_id",
    "distance_km",
    "weight_kg",
    "service_type",
    "dispatch_hour",
    "dispatch_weekday",
    "actual_duration_hours",
]

# Hong Kong: UTC+8, no daylight saving.
HONG_KONG_OFFSET_HOURS = 8

# Validation ranges matching the model's training domain.
RANGES = {"distance_km": (1.0, 60.0), "weight_kg": (0.1, 25.0)}


def _first_log(conn, shipment_id, status, not_before=None):
    """First log with the given status, optionally only events that happen
    strictly after `not_before` = (created_at, id) of the dispatch event.

    Time is the primary key of the ordering (ISO strings compare correctly);
    id only breaks exact ties so a same-second delivered click is not taken
    before the dispatch click it follows.
    """
    if not_before is None:
        row = conn.execute(
            """
            SELECT id, created_at FROM tracking_logs
            WHERE shipment_id = ? AND status = ?
            ORDER BY created_at, id LIMIT 1
            """,
            (shipment_id, status),
        ).fetchone()
    else:
        at, log_id = not_before
        row = conn.execute(
            """
            SELECT id, created_at FROM tracking_logs
            WHERE shipment_id = ? AND status = ?
              AND (created_at > ? OR (created_at = ? AND id > ?))
            ORDER BY created_at, id LIMIT 1
            """,
            (shipment_id, status, at, at, log_id),
        ).fetchone()
    return row


def export(db_path: Path) -> dict:
    if not db_path.exists():
        print(f"Database not found: {db_path}")
        print("Start the backend once first, or pass the path: "
              "python -m ai_module.export_training_records path/to/delivery_demo.db")
        return {"written": 0}

    conn = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True)
    stats = {
        "delivered_shipments": 0,
        "written": 0,
        "skipped_no_dispatch_event": 0,
        "skipped_no_delivery_event": 0,
        "skipped_missing_details": 0,
        "skipped_invalid_range": 0,
        "skipped_non_positive_duration": 0,
    }
    rows = []
    try:
        shipments = conn.execute(
            """
            SELECT id, distance_km, weight_kg, service_type FROM shipments
            WHERE status = 'delivered'
            ORDER BY id
            """
        ).fetchall()
        stats["delivered_shipments"] = len(shipments)

        for shipment_id, distance, weight, service in shipments:
            if distance is None or weight is None or service not in ("standard", "express"):
                stats["skipped_missing_details"] += 1
                continue

            dispatch = _first_log(conn, shipment_id, "in_transit")
            if dispatch is None:
                stats["skipped_no_dispatch_event"] += 1
                continue
            delivered = _first_log(
                conn, shipment_id, "delivered", not_before=(dispatch[1], dispatch[0])
            )
            if delivered is None:
                stats["skipped_no_delivery_event"] += 1
                continue

            from datetime import datetime, timedelta

            dispatch_dt = datetime.fromisoformat(dispatch[1])
            delivered_dt = datetime.fromisoformat(delivered[1])
            duration_hours = (delivered_dt - dispatch_dt).total_seconds() / 3600.0
            if duration_hours <= 0:
                stats["skipped_non_positive_duration"] += 1
                continue

            ok = all(
                RANGES[field][0] <= value <= RANGES[field][1]
                for field, value in (("distance_km", distance), ("weight_kg", weight))
            )
            if not ok:
                stats["skipped_invalid_range"] += 1
                continue

            dispatch_local = dispatch_dt + timedelta(hours=HONG_KONG_OFFSET_HOURS)
            rows.append([
                shipment_id,
                distance,
                weight,
                service,
                dispatch_local.hour,
                dispatch_local.weekday(),  # 0 = Monday
                round(duration_hours, 4),
            ])
            stats["written"] += 1
    finally:
        conn.close()

    DATA_DIR.mkdir(parents=True, exist_ok=True)
    with OUTPUT_PATH.open("w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(HEADER)
        writer.writerows(rows)

    print(f"Exported {stats['written']} record(s) to {OUTPUT_PATH}")
    print("Report:")
    for key, value in stats.items():
        if key != "written":
            print(f"  {key}: {value}")
    print("NOTE: these records reflect whatever activity is in the database.")
    print("If the database holds demonstration data, the durations are demo")
    print("clicks, not real logistics operations. Do not present retrained")
    print("results as real-world accuracy.")
    return stats


if __name__ == "__main__":
    target = Path(sys.argv[1]) if len(sys.argv) > 1 else DEFAULT_DB
    export(target)
