"""FastAPI wrapper exposing the AI module to the team backend.

Run locally:
    uvicorn ai_module.api:app --reload

Integration contract for Member 6 (backend):
    POST /api/ai/predict-delivery with a JSON body of dispatch-time fields.
    The endpoint never crashes on bad input: invalid input returns 422,
    a missing model returns 200 with prediction_status="unavailable".
    Showing the fallback message on the shipment page itself is pending
    frontend integration (Member 7).

Frontend contract for Member 7 (proposed):
    Display predicted_duration_hours as an estimate, e.g.
    "Estimated delivery duration: about 1.3 hours".
    If prediction_status != "available", show "Estimate currently unavailable".
"""

from fastapi import FastAPI
from pydantic import BaseModel, Field

from ai_module.predictor import PredictionUnavailableError, Predictor, get_predictor

app = FastAPI(
    title="Logistics AI Module",
    description="Delivery-duration prediction for the Logistics Management System",
    version="1.0.0",
)


class DeliveryRequest(BaseModel):
    distance_km: float = Field(ge=1, le=60, description="Planned delivery distance (km; training domain 1-60)")
    weight_kg: float = Field(ge=0.1, le=25, description="Parcel weight (kg; training domain 0.1-25)")
    service_type: str = Field(description="'standard' or 'express'")
    dispatch_hour: int = Field(ge=0, le=23, description="Hour of dispatch, 0-23")
    dispatch_weekday: int = Field(ge=0, le=6, description="0 = Monday ... 6 = Sunday")


class UnavailableResponse(BaseModel):
    predicted_duration_hours: float | None = None
    model_version: str | None = None
    prediction_status: str = "unavailable"
    message: str = "Estimate currently unavailable"


@app.get("/health")
def health() -> dict:
    """Liveness probe so the backend can check the AI service is up."""
    return {"status": "ok"}


@app.post("/api/ai/predict-delivery")
def predict_delivery(req: DeliveryRequest) -> dict:
    predictor: Predictor = get_predictor()
    try:
        return predictor.predict(req.model_dump())
    except ValueError as exc:
        # Pydantic already validates ranges; this covers service_type etc.
        from fastapi import HTTPException

        raise HTTPException(status_code=422, detail=str(exc)) from exc
    except PredictionUnavailableError as exc:
        # Deliberately 200 + unavailable payload: the page must keep working.
        return UnavailableResponse(message=f"Estimate currently unavailable ({exc})").model_dump()
