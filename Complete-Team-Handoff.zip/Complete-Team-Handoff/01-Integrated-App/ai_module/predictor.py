"""Prediction wrapper: loads the saved model and predicts delivery duration.

This module is the integration point for the backend (Member 6).
"""

from pathlib import Path
from typing import Optional

import joblib
import pandas as pd

MODEL_PATH = Path(__file__).resolve().parent.parent / "artifacts" / "delivery_duration_model.joblib"
MODEL_VERSION = "eta-v1"

REQUIRED_FIELDS = ["distance_km", "weight_kg", "service_type", "dispatch_hour", "dispatch_weekday"]


class PredictionUnavailableError(RuntimeError):
    """Raised when the model artifact is missing or prediction fails."""


class Predictor:
    """Wraps the trained sklearn pipeline behind a stable interface."""

    def __init__(self, model_path: Path = MODEL_PATH):
        self.model_path = model_path
        self._pipeline = None

    @property
    def pipeline(self):
        if self._pipeline is None:
            if not self.model_path.exists():
                raise PredictionUnavailableError(
                    f"Model artifact not found at {self.model_path}. Run ai_module.train_model first."
                )
            self._pipeline = joblib.load(self.model_path)
        return self._pipeline

    def predict(self, sample: dict) -> dict:
        """Validate one dispatch-time sample and return a prediction payload.

        Raises ValueError for invalid input, PredictionUnavailableError if the
        model is missing. The API layer maps both to a clean response; showing
        the fallback message on the shipment page is pending frontend work.
        """
        missing = [f for f in REQUIRED_FIELDS if f not in sample or sample[f] is None]
        if missing:
            raise ValueError(f"Missing required field(s): {', '.join(missing)}")

        distance = float(sample["distance_km"])
        weight = float(sample["weight_kg"])
        hour = int(sample["dispatch_hour"])
        weekday = int(sample["dispatch_weekday"])
        service = str(sample["service_type"]).strip().lower()

        # Input domain matches the training data exactly (synthetic records
        # use 1-60 km and 0.1-25 kg). Values outside it are rejected because
        # the model has not been evaluated beyond this range.
        if not 1 <= distance <= 60:
            raise ValueError("distance_km must be between 1 and 60 km")
        if not 0.1 <= weight <= 25:
            raise ValueError("weight_kg must be between 0.1 and 25 kg")
        if not float(sample["dispatch_hour"]).is_integer() or not 0 <= hour <= 23:
            raise ValueError("dispatch_hour must be a whole number 0-23")
        if not float(sample["dispatch_weekday"]).is_integer() or not 0 <= weekday <= 6:
            raise ValueError("dispatch_weekday must be a whole number 0-6 (0 = Monday)")
        if service not in ("standard", "express"):
            raise ValueError("service_type must be 'standard' or 'express'")

        frame = pd.DataFrame(
            [{
                "distance_km": distance,
                "weight_kg": weight,
                "service_type": service,
                "dispatch_hour": hour,
                "dispatch_weekday": weekday,
            }]
        )
        try:
            hours = float(self.pipeline.predict(frame)[0])
        except PredictionUnavailableError:
            raise
        except Exception as exc:  # any unexpected model failure
            raise PredictionUnavailableError(f"Prediction failed: {exc}") from exc

        return {
            "predicted_duration_hours": round(max(hours, 0.25), 2),
            "model_version": MODEL_VERSION,
            "prediction_status": "available",
        }


_default_predictor: Optional[Predictor] = None


def get_predictor() -> Predictor:
    """Module-level singleton so the API reloads the model once, not per request."""
    global _default_predictor
    if _default_predictor is None:
        _default_predictor = Predictor()
    return _default_predictor
