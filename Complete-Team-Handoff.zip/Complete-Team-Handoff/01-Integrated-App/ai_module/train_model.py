"""Train the delivery-duration prediction model.

Pipeline: one-hot encoding for service_type, passthrough numeric features,
then a GradientBoostingRegressor. The model is saved with joblib.

Usage:
    python -m ai_module.train_model
"""

from pathlib import Path

import joblib
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder

DATA_PATH = Path(__file__).resolve().parent.parent / "data" / "deliveries.csv"
ARTIFACTS_DIR = Path(__file__).resolve().parent.parent / "artifacts"
MODEL_PATH = ARTIFACTS_DIR / "delivery_duration_model.joblib"

FEATURE_COLUMNS = [
    "distance_km",
    "weight_kg",
    "service_type",
    "dispatch_hour",
    "dispatch_weekday",
]
TARGET_COLUMN = "actual_duration_hours"
RANDOM_SEED = 42


def build_pipeline() -> Pipeline:
    """Feature preprocessing + model as one sklearn Pipeline."""
    preprocessor = ColumnTransformer(
        transformers=[
            ("service_type", OneHotEncoder(handle_unknown="ignore"), ["service_type"]),
            ("numeric", "passthrough", ["distance_km", "weight_kg", "dispatch_hour", "dispatch_weekday"]),
        ]
    )
    model = GradientBoostingRegressor(random_state=RANDOM_SEED)
    return Pipeline([("preprocessor", preprocessor), ("model", model)])


def main():
    df = pd.read_csv(DATA_PATH)

    # Split first; never fit preprocessing or model on test data.
    train_df, test_df = train_test_split(
        df, test_size=0.2, random_state=RANDOM_SEED
    )

    pipeline = build_pipeline()
    pipeline.fit(train_df[FEATURE_COLUMNS], train_df[TARGET_COLUMN])

    ARTIFACTS_DIR.mkdir(parents=True, exist_ok=True)
    joblib.dump(pipeline, MODEL_PATH)

    train_mae = (pipeline.predict(train_df[FEATURE_COLUMNS]) - train_df[TARGET_COLUMN]).abs().mean()
    test_mae = (pipeline.predict(test_df[FEATURE_COLUMNS]) - test_df[TARGET_COLUMN]).abs().mean()
    print(f"Train records: {len(train_df)}  Test records: {len(test_df)}")
    print(f"Train MAE: {train_mae:.3f} hours   Test MAE: {test_mae:.3f} hours")
    print(f"Model saved to {MODEL_PATH}")


if __name__ == "__main__":
    main()
