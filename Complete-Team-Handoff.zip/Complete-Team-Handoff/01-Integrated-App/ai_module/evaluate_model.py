"""Evaluate the trained model against a simple baseline on held-out test data.

Baseline: always predict the median delivery duration of the TRAINING set.
Both the model and the baseline are scored on the same test records.

Usage:
    python -m ai_module.evaluate_model
"""

from pathlib import Path

import joblib
import pandas as pd
from sklearn.metrics import mean_absolute_error
from sklearn.model_selection import train_test_split

from ai_module.train_model import (
    FEATURE_COLUMNS,
    MODEL_PATH,
    RANDOM_SEED,
    TARGET_COLUMN,
)

DATA_PATH = Path(__file__).resolve().parent.parent / "data" / "deliveries.csv"


def main():
    df = pd.read_csv(DATA_PATH)
    train_df, test_df = train_test_split(df, test_size=0.2, random_state=RANDOM_SEED)
    pipeline = joblib.load(MODEL_PATH)

    # Baseline: training-set median duration, applied to every test record.
    baseline_prediction = train_df[TARGET_COLUMN].median()
    baseline_mae = mean_absolute_error(
        test_df[TARGET_COLUMN], [baseline_prediction] * len(test_df)
    )

    model_predictions = pipeline.predict(test_df[FEATURE_COLUMNS])
    model_mae = mean_absolute_error(test_df[TARGET_COLUMN], model_predictions)

    print(f"Test records evaluated: {len(test_df)}")
    print(f"Baseline (median) MAE:  {baseline_mae:.3f} hours")
    print(f"Model MAE:              {model_mae:.3f} hours")
    print(f"Improvement over baseline: {baseline_mae - model_mae:.3f} hours "
          f"({(baseline_mae - model_mae) / baseline_mae * 100:.1f}%)")


if __name__ == "__main__":
    main()
