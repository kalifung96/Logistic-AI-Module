﻿# Member 6 — Three-minute Presentation

Use a 16:9 slide layout. Put the editable bullet text on the left and the corresponding screenshot on the right. Screenshots show the actual local application; existing records are user-entered demo data.

## Slide 1 — Delivery Management System (35 seconds)

- My role: Backend Core Developer
- FastAPI for REST APIs
- SQLAlchemy for database access; SQLite for the local demo
- A browser interface for everyday operations

Image: 01-orders.jpg

Speaker notes:
Hello everyone. I am Member Six, and my responsibility is the core backend of our delivery management system. The backend uses Python and FastAPI to process requests, while SQLAlchemy handles database access. Our local demonstration uses SQLite. I will demonstrate the system through its browser interface. Users can fill in forms and click buttons, while the interface sends requests to the backend and displays the results.

## Slide 2 — Order and Delivery Workflow (65 seconds)

- Create an order with customer, product and quantity
- Assign a courier to an existing order
- Update delivery status and current location
- View the tracking history
- Marking a shipment delivered also updates its order

Image: 02-tracking.jpg

Speaker notes:
The main workflow begins with an order. An administrator or customer enters the customer name, product and quantity. The backend saves the order and returns a unique identifier. Next, an administrator selects that order and assigns a courier to create a shipment. The system checks that the order exists and prevents duplicate shipments for the same order. An administrator or courier can then update the delivery status, location and notes. Each update creates a tracking record, so users can review the delivery history. When a shipment is marked as delivered, the associated order is also marked as delivered. These linked updates keep the order and shipment information consistent at completion.

## Slide 3 — Inventory and Business Validation (40 seconds)

- Add inventory items and record stock movements
- Reject stock-out requests when stock is insufficient
- Validate positive quantities and required fields
- Save changes to the database

Image: 03-inventory.jpg

Speaker notes:
The inventory module allows administrators to add products. Administrators and couriers can record stock entering or leaving inventory. Before a stock-out operation, the backend checks the available quantity. If the request exceeds the remaining stock, the operation is rejected. Input validation also checks required fields and positive quantities. Inventory movements are separate operations in this version: creating an order does not automatically reduce stock. This makes the current scope clear and avoids claiming an integration that has not been implemented.

## Slide 4 — Exceptions, Permissions and Next Steps (40 seconds)

- Report delivery problems and resolve exception records
- Restrict operations by administrator, courier and customer roles
- Current scope: coursework prototype with fixed demo tokens
- Next steps: secure authentication, customer data isolation and automated tests

Image: 04-exceptions.jpg

Speaker notes:
The exception module records delivery problems, such as delays. Administrators and couriers can report a problem, and administrators can mark it as resolved. Access checks restrict actions according to the user's role. This version is a coursework prototype and uses fixed demonstration tokens. Future improvements include secure authentication, restricting customers to their own records, and more automated tests. My contribution connects the user interface to validated backend operations and persistent storage. Thank you.
