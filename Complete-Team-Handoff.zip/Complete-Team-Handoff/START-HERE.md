﻿# 小组完整交接包 / Complete Team Handoff

## 先看这里
这是本次交接的总入口。需要演示或继续开发时，请使用 01-Integrated-App；其他目录是原始来源、汇报材料及历史版本。

### 快速启动
1. 完整解压压缩包。
2. 安装 Python 3.12，并勾选 Add Python to PATH。
3. 打开 01-Integrated-App，双击 START-WINDOWS.bat。首次运行需联网下载依赖。
4. 看到 Uvicorn running 后打开 http://127.0.0.1:8002/app 。
5. 管理员 admin / admin123；配送员 courier / courier123；客户 customer / customer123。
6. 运行期间保持命令窗口打开，按 Ctrl+C 停止。

注意：127.0.0.1 是每位组员自己的电脑地址，并非已发布的公网网站。

## 目录
- 01-Integrated-App：本次整合后的完整源码、AI 模型、数据、测试、启动脚本和说明。分享版不包含运行数据库，首次启动创建空数据库。
- 02-Original-Projects：用户提供的 Member6-Team-Package、Member8-AI-module、ui，以及本机 member6_backend_project 的文件快照。历史目录中的数据库仅作留档，不要覆盖整合项目数据库。
- 03-Presentation：四页英文 PPT 文案、约三分钟英文讲稿及真实页面截图。当前交付是文案与图片，并非制作完成的 PPTX。
- 04-Uploaded-Files：用户通过聊天提供的代码、模型、报告、记录和集成资料原文件；散放文件应作为参考，运行请使用 01-Integrated-App 中的正确模块结构。
- 05-Assignment-References：桌面 35000 文件夹中的作业 PDF 和三张参考图。
- 06-Handoff：本次修改说明、验证记录和演示步骤。
- 07-Previous-Deliverables：仍可找到的历史项目分享压缩包。
- 08-Member8-Final-Deliverables：Member 8 最终提交文件（logbook、AI 使用声明、报告段落、整合验证报告，日期 2026-10-31，均已按已完成的整合状态更新）。
- MANIFEST.txt：压缩包收录文件清单。

没有打包 Python 安装程序、虚拟环境、缓存和系统生成的 macOS 元数据文件；这些不是项目源码。依赖通过 requirements.txt 安装。

## 三分钟演示建议
1. 管理员登录。
2. Orders：创建客户 Alex、商品 Laptop、数量 1 的订单。
3. Deliveries & Tracking：选择刚创建的订单，填写 Courier Sam、Distance 18.5、Weight 2、Service Standard，创建运单。
4. Update tracking：选择运单，状态 In transit，位置 Sorting centre，备注 Dispatched，保存。
5. Tracking timeline：选择运单并查看轨迹。
6. AI delivery estimate：选择运单，点击 View estimate。
7. 简要介绍 Inventory 和 Exceptions，说明角色权限与后续工作。

## AI 结果解释
- 首次 In transit 事件代表发货时间；未发货时不会返回预测。
- 预测的是从发货开始的总时长，不是当前剩余时间。
- 已送达时返回 not_applicable。
- 模型基于合成数据训练，不能据此证明实际配送准确率。
- 当前角色权限及固定演示令牌属于课程原型，不是生产安全方案；客户数据隔离尚待完善。
